package cl.duoc.actividadcatalogo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class Detalle extends AppCompatActivity {
    protected Catalogo Items;
    protected ImageView imagenFoto;
    protected TextView nombreProducto;
    protected TextView desProducto;
    protected TextView precio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        Items = (Catalogo)getIntent().getParcelableExtra( "productos" ) ;

        //inicializar todos los elemntos que llamo a la nueva vista
        imagenFoto = findViewById( R.id.det_ivProducto );
        nombreProducto = findViewById( R.id.det_tvNombre );
        desProducto=findViewById( R.id.det_tvDescripcion );
        precio = findViewById( R.id.det_tvPrecio );

        // pasar datos los elementos de la nueva vist
        // Log.i("bebida","test..........................................");
        String nomProducto = getIntent().getStringExtra( "NombreProducto"  );
        Log.i("data",String.valueOf(nomProducto));

        String descripcionProducto = getIntent().getStringExtra( "DescripcionProducto" );
        String precioProducto = getIntent().getStringExtra( "Precio"  );

        String foto = getIntent().getStringExtra( "Imagen" );
        int foto1 = Integer.valueOf( foto );
        Log.i("data",String.valueOf(foto));
        imagenFoto.setImageResource( foto1 );


        nombreProducto.setText( nomProducto );
        desProducto.setText( descripcionProducto );
        precio.setText( "$  " + precioProducto );



    }



    }
