package cl.duoc.actividadcatalogo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ModificarCategoria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_categoria);

        mostrarCategorias();
        //Conecto la base de datos
        Conexion con = new Conexion(this, "Catalogo", null, 1);

        Button btnModificar = findViewById(R.id.btnModificar);
        Button btnVolver = findViewById(R.id.btnVolver);

        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Traigo los elementos de layout modificar_categorias
                TextView txtId = findViewById(R.id.txtIdCategoria);
                EditText txtNombre = findViewById(R.id.txtNombreCategoria);

                //Llamar el id que se quiere modificar
                String id = txtId.getText().toString();
                //int id= Integer.parseInt(txtId.getText().toString());
                String nombre = txtNombre.getText().toString();

                //validación de datos
                if(!id.isEmpty()){
                    if(!nombre.isEmpty()){
                        mostrarCategorias();
                        //Llamo a la clase Categorias y guardo el id que quiero modificar
                        Categorias categoria = new Categorias(Integer.parseInt(id),nombre);
                        //llamo al metodo para actualizar el registro en la base de datos
                        con.actualizar( null, null, categoria, "categorias",3);

                        Toast.makeText(ModificarCategoria.this, "Categoria Actualizada, vuelve a iniciar sesión.", Toast.LENGTH_LONG).show();
                        finish();
                        startActivity(getIntent());
                    }else{
                        txtNombre.setError("el campo no puede estar vacio");
                    }
                }else{
                    txtId.setError("El ID no puede ir vácio");
                }


            }
        });
    }
    private void mostrarCategorias()
    {
        Conexion sql = new Conexion(ModificarCategoria.this,"Catalogo",null,1);
        ArrayList<Categorias> categoriasTodas = sql.buscarCategoriasTodos();

        Log.i("categoria adapter", String.valueOf(categoriasTodas));
        AdaptadorCategoria adapter = new AdaptadorCategoria(this,R.layout.plantilla_modificar_categoria,categoriasTodas);
        ListView lvLista = findViewById(R.id.mc_lvCategorias);
        lvLista.setAdapter(adapter);
    }
}

class AdaptadorCategoria extends ArrayAdapter<Categorias>
{
    private Context miContexto;
    private int miRecurso;
    private ArrayList<Categorias> miLista;

    public AdaptadorCategoria(@NonNull Context context, int resource, @NonNull ArrayList<Categorias> objects) {
        super(context, resource, objects);
        miContexto = context;
        miRecurso = resource;
        miLista = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(miContexto).inflate(miRecurso,null);

        TextView lblId = view.findViewById(R.id.pmc_tvId);
        TextView lblNombre = view.findViewById(R.id.pmc_tvNombre);
        ImageView ivImagen = view.findViewById(R.id.pmc_ivImagen);

        Categorias c = miLista.get(position);

        lblId.setText(String.valueOf(c.getId()));
        lblNombre.setText(String.valueOf(c.getNombre()));
        ivImagen.setImageResource(c.getImagen());

        return view;
    }
}