package cl.duoc.actividadcatalogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    //Codigos categoria
    public int cod_bebestibles = 1;
    public int cod_sandwish = 2;
    public int cod_pasteleria = 3;
    public int cod_panaderia = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //se traen botones categorias
        ImageButton ibBebestibles = findViewById(R.id.ibBebestible);
        ImageButton ibSandwish = findViewById(R.id.ibSandwich);
        ImageButton ibPasteleria = findViewById(R.id.ibPasteleria);
        ImageButton ibPanaderia = findViewById(R.id.ibPanaderia);

        //Categoria Bebestibles
        ibBebestibles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_bebestibles);
                startActivity(intento);
            }
        });

        //Categoria Sandwish
        ibSandwish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_sandwish);
                startActivity(intento);
            }
        });

        //Categoria Pastelería
        ibPasteleria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_pasteleria);
                startActivity(intento);
            }
        });

        //Categoría Panadería
        ibPanaderia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_panaderia);
                startActivity(intento);
            }
        });
    }
}