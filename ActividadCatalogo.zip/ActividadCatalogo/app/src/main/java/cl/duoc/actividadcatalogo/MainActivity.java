package cl.duoc.actividadcatalogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Codigos categoria
    public int cod_bebestibles = 1;
    public int cod_sandwish = 2;
    public int cod_pasteleria = 3;
    public int cod_panaderia = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Se crea BD
        Conexion con = new Conexion(MainActivity.this,"Catalogo",null,1);
        //Se crean categorias
        Categorias c1 = new Categorias("Bebestibles","Productos liquidos",0);
        Categorias c2 = new Categorias("Sandwish","Comestible",0);
        Categorias c3 = new Categorias("Pastelería","Tortas",0);
        Categorias c4 = new Categorias("Panadería","Pan",0);

        //Se crea usuario defecto
        Usuarios u1 = new Usuarios("administrador","administrador","admin@admin.cl",1,true,"admin123");

        //Se agrega a bd
        //Se inserta categoria defecto
        con.insertar(null,null,c1,"categorias",3);
        con.insertar(null,null,c2,"categorias",3);
        con.insertar(null,null,c3,"categorias",3);
        con.insertar(null,null,c4,"categorias",3);

        //Se inserta usuario defecto(administrador)
        con.insertar(null,u1,null,"usuarios",2);

        //se traen botones categorias
        ImageButton ibBebestibles = findViewById(R.id.ibBebestible);
        ImageButton ibSandwish = findViewById(R.id.ibSandwich);
        ImageButton ibPasteleria = findViewById(R.id.ibPasteleria);
        ImageButton ibPanaderia = findViewById(R.id.ibPanaderia);

        //Categoria Bebestibles
        ibBebestibles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_bebestibles);
                startActivity(intento);
            }
        });

        //Categoria Sandwish
        ibSandwish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_sandwish);
                startActivity(intento);
            }
        });

        //Categoria Pastelería
        ibPasteleria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_pasteleria);
                startActivity(intento);
            }
        });

        //Categoría Panadería
        ibPanaderia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_panaderia);
                startActivity(intento);
            }
        });
    }
}