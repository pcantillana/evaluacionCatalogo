package cl.duoc.actividadcatalogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //Codigos categoria
    public int cod_bebestibles = 1;
    public int cod_sandwish = 2;
    public int cod_pasteleria = 3;
    public int cod_panaderia = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Se crea BD
        Conexion con = new Conexion(MainActivity.this,"Catalogo",null,1);

        //Se crean categorias
        Categorias c1 = new Categorias("Bebestibles","Productos liquidos", R.drawable.bebestibles30);
        Categorias c2 = new Categorias("Sandwish","Comestible",R.drawable.sandwich4);
        Categorias c3 = new Categorias("Pastelería","Tortas",R.drawable.pasteleria31);
        Categorias c4 = new Categorias("Panadería","Pan",R.drawable.panaderia);

        //  Log.i("Imagen: ", String.valueOf(R.drawable.bebestibles30));
        //Se crea usuario defecto
        Usuarios u1 = new Usuarios("administrador","administrador","admin@admin.cl",1,true,"admin123");

        //Se agrega a bd
        //Se inserta categoria defecto
        con.insertar(null,null,c1,"categorias",3);
        con.insertar(null,null,c2,"categorias",3);
        con.insertar(null,null,c3,"categorias",3);
        con.insertar(null,null,c4,"categorias",3);

        //Se inserta usuario defecto(administrador)
        con.insertar(null,u1,null,"usuarios",2);
        /* Hasta aqui es el código defecto*/

        //se traen botones categorias
        ImageButton ibBebestibles = findViewById(R.id.ibBebestible);
        TextView tvBebestible = findViewById(R.id.tvBebestible);


        ArrayList<Categorias> categoriasTodas = new ArrayList<>();
        categoriasTodas = con.buscarCategoriasTodos();

        String bebNombre= String.valueOf(categoriasTodas.get(0).getNombre());
        String bebDescripcion= String.valueOf(categoriasTodas.get(0).getDescripcion());
        int bebImagen= categoriasTodas.get(0).getImagen();
        ibBebestibles.setImageResource(bebImagen); //muestra imagen de BD
        tvBebestible.setText(bebNombre);    //Muestra nombre de BD

        Log.i("imagen BD",String.valueOf(bebImagen));
        //Toast.makeText(this,bebestible1, Toast.LENGTH_SHORT).show();
        ImageButton ibSandwish = findViewById(R.id.ibSandwich);
        ImageButton ibPasteleria = findViewById(R.id.ibPasteleria);
        ImageButton ibPanaderia = findViewById(R.id.ibPanaderia);

        //Categoria Bebestibles
        ibBebestibles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_bebestibles);
                startActivity(intento);
            }
        });

        //Categoria Sandwish
        ibSandwish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_sandwish);
                startActivity(intento);
            }
        });

        //Categoria Pastelería
        ibPasteleria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_pasteleria);
                startActivity(intento);
            }
        });

        //Categoría Panadería
        ibPanaderia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intento = new Intent(MainActivity.this, Productos.class );
                intento.putExtra("categoria", cod_panaderia);
                startActivity(intento);
            }
        });
    }
}