package cl.duoc.actividadcatalogo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Productos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);
        //Se crea productos
        //Catalogo producto = new Catalogo(1,"Budweiser","Refrescante sabor.",1000,0);
        Catalogo producto = new Catalogo();
        //Se crea arrayList
        ArrayList<Catalogo> p = new ArrayList<>();

        ListView lvListar = findViewById(R.id.lvProductos);

        int categoria = getIntent().getIntExtra("categoria", 0);

        switch (categoria){
            case 1:
                Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
                //Catalogo producto = new Catalogo(1,"Budweiser","Refrescante sabor.",1000,0);
                producto.setCategoria(1);
                producto.setNombre("Budweiser");
                producto.setDescripcion("Refrescante sabor");
                producto.setPrecio(1000);
                producto.setImagen(R.drawable.budweiser);
                p.add(producto);

                producto.setCategoria(1);
                producto.setNombre("Budweiser");
                producto.setDescripcion("Refrescante sabor");
                producto.setPrecio(1000);
                producto.setImagen(R.drawable.budweiser);
                p.add(producto);

                producto.setCategoria(1);
                producto.setNombre("Budweiser");
                producto.setDescripcion("Refrescante sabor");
                producto.setPrecio(1000);
                producto.setImagen(R.drawable.budweiser);
                p.add(producto);

                producto.setCategoria(1);
                producto.setNombre("Budweiser");
                producto.setDescripcion("Refrescante sabor");
                producto.setPrecio(1000);
                producto.setImagen(R.drawable.budweiser);
                p.add(producto);
                break;
            case 2:
                Toast.makeText(this, "cat2", Toast.LENGTH_SHORT).show();
                break;
            case 3:
                Toast.makeText(this, "cat3", Toast.LENGTH_SHORT).show();
                break;
            case 4:
                Toast.makeText(this, "cat4", Toast.LENGTH_SHORT).show();
                break;
            default:
                Toast.makeText(this, "Ponte vivaldi, no esta disponible.", Toast.LENGTH_SHORT).show();
                    break;
        }

        //List view personalizado
        CustomArrayAdapter adaptador = new CustomArrayAdapter(Productos.this,R.layout.plantilla_lv_productos,p);
        lvListar.setAdapter(adaptador);
    }
}


class CustomArrayAdapter extends ArrayAdapter<Catalogo>
{
    private Context miContexto;
    private int miRecurso;
    private ArrayList<Catalogo> miLista;

    public CustomArrayAdapter(Productos miContexto, int miRecurso, ArrayList<Catalogo> miLista) {
        super(miContexto, miRecurso, miLista);
        this.miContexto = miContexto;
        this.miRecurso = miRecurso;
        this.miLista = miLista;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(getContext()).inflate(miRecurso, null);
        ImageView lblImagen = view.findViewById(R.id.lblImagen);
        TextView lblNombre = view.findViewById(R.id.lblNombre);

        Catalogo p = miLista.get(position);

        lblImagen.setImageResource(p.getImagen());
        lblNombre.setText(String.valueOf(p.getNombre()));
        return view;
    }
}